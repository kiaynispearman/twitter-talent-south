require "application_system_test_case"

class TweetsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit tweets_url
  #
  #   assert_selector "h1", text: "Tweet"
  # end
end
